// OPT算法 最佳淘汰算法
#include <vector>
#include <fstream>
#include <iostream>

using namespace std;

class OPT
{
public:
    OPT(const vector<short> &A, int maxN, bool verbose);

    void run();

private:
    void getPageNo();
    vector<short> a;
    vector<int> pageno;
    int pagesize = 1024;
    int maxN = 32;
    bool verbose = false;
};
// LRU 最近最少使用
#include <vector>
#include <fstream>
#include <iostream>

using namespace std;

class LRU {
public:
    LRU(const vector<short> &A, int maxN, bool verbose); // 构造

    void run();

private:
    void getPageNo();
    vector<short> a;
    vector<int> pageno;
    int pagesize = 1024;
    int maxN = 32;
    bool verbose = false;
};
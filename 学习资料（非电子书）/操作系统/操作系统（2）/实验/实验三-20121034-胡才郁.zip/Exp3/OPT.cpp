#include "OPT.h"

using namespace std;

OPT::OPT(const vector<short> &A, int maxN, bool verbose) : maxN(maxN), verbose(verbose) {
    a = vector<short>(A);
    pageno.resize(A.size());
}

void OPT::run() {
    getPageNo();
    ofstream out("opt.txt");
    for (int pageAssigned = 4; pageAssigned <= maxN; pageAssigned += 2) // 实存容量从4-32页
    {
        printf("PAGE NUMBER WITH SIZE %dk EACH ADDRESS IS:\n",
               pagesize / 1024);
        vector<int> memory;           // 内存
        int miss = 0;                           // 记录缺页次数
        for (int i = 0; i < pageno.size(); i++) // 每一个要装入的page都进入
        {
            auto index = find(memory.begin(), memory.end(), pageno[i]);
            // index 遍历memory找到pageno[i]的位置， 如果没找到，最终会指向memory.end()
            if (index != memory.end()) // 该页命中
            {
                if (verbose)
                    cout << "命中 ";
            } else // 没命中的时候
            {
                if (memory.size() < pageAssigned) // 还有空余的内存
                {
                    if (verbose)
                        cout << "装入 ";
                    memory.push_back(pageno[i]);
                } else // 没有空余内存 要置换
                {
                    if (verbose)
                        cout << "置换 ";

                    int maxindex = i;
                    int position = 0;
                    for (int j = 0; j < memory.size(); j++) // 用j来找出要被换走的页面-OPT算法是找到pageno中最晚出现的页
                    {
                        int k = find(pageno.begin() + i + 1, pageno.end(), memory[j]) - pageno.begin();
                        // k表示找到memory[j]所表示页面的位置
                        if (k == pageno.end() - (pageno.begin() + i + 1)) {
                            // 表示memory[j]表示的页是画物理内存最后一页了
                            position = j;
                            break;
                        } else
                            // 表示找到了memory[j]表示的页
                        {
                            if (k > maxindex) // ii比当前的maxindex大 所以更新maxindex
                            {
                                maxindex = k;
                                position = j;
                            }
                        }
                    }
                    memory[position] = pageno[i]; // 置换完毕
                }
                miss++; // 缺页次数+1
            }
            if (verbose) {
                cout << "memory: ";

                for (int k: memory)
                    printf("%d ", k);
                cout << endl;
            }
        }
        printf("%-10d 命中率： %3f\n", pageAssigned, 1 - miss * 1.0 / pageno.size());
        cout << endl;
        out << miss * 1.0 / pageno.size() << endl;
        pagesize *= 2;
    }
    out.close();
}

/**
 * @brief 获取每一个物理地址对应的页号
 */
void OPT::getPageNo() {
    for (int i = 0; i < a.size(); i++) {
        pageno[i] = a[i] / pagesize + 1;
        if (verbose) {
            printf("pageno[%d]=%-10d", i, pageno[i]);
            if ((i + 1) % 4 == 0)
                cout << endl;
        }
    }
}

#include "FIFO.h"

using namespace std;

FIFO::FIFO(const vector<short> &A, int maxN, bool verbose) : pagesize(maxN), verbose(verbose) {
    a = vector<short>(A);
    pageno.resize(A.size());
}

void FIFO::run() {
    getPageNo();
    ofstream out("fifo.txt");
    for (int pageAssigned = 4; pageAssigned <= maxN; pageAssigned += 2) {
        printf("PAGE NUMBER WITH SIZE %dk EACH ADDRESS IS:\n", pagesize / 1024);
        vector<int> memory;
        int miss = 0;
        for (int i: pageno) {
            // 从内存中找到pageno[i]所表示的页
            auto index = find(memory.begin(), memory.end(), i);
            if (index != memory.end()) {
                if (verbose)
                    cout << "命中 ";
            } else {
                if (verbose)
                    cout << "缺页 ";
                if (memory.size() < pageAssigned)
                    // 有空闲页
                {
                    memory.push_back(i);
                    if (verbose)
                        cout << "装入 ";
                } else
                    // 无空闲页
                {
                    // 置换
                    if (verbose)
                        cout << "置换 ";
                    for (int k = 1; k < memory.size(); k++) {
                        // 将所有页向前移动一位
                        memory[k - 1] = memory[k];
                    }
                    // 将新页放到最后
                    memory[memory.size() - 1] = i;
                }
                miss++;
            }

            if (verbose) {
                cout << "memory: ";

                for (int k: memory)
                    printf("%d ", k);
                cout << endl;
            }
        }
        printf("%-10d 命中率： %3f\n", pageAssigned, 1 - miss * 1.0 / pageno.size());
        cout << endl;
        out << miss * 1.0 / pageno.size() << endl;
        pagesize *= 2;
    }
    out.close();
}

/**
 * @brief 获取每一个物理地址对应的页号
 */
void FIFO::getPageNo() {
    for (int i = 0; i < a.size(); i++) {
        pageno[i] = a[i] / pagesize + 1;
        if (verbose) {
            printf("pageno[%d]=%-10d", i, pageno[i]);
            if ((i + 1) % 4 == 0)
                cout << endl;
        }
    }
}

// FIFO 先进先出算法
#include <vector>
#include <fstream>
#include <iostream>

using namespace std;

class FIFO
{
public:
    FIFO(const vector<short> &A, int maxN, bool verbose);

    void run();

private:
    void getPageNo();
    vector<short> a;
    vector<int> pageno;
    int pagesize = 1024;
    int maxN = 32;
    int clock = 0;
    bool verbose = false;
};
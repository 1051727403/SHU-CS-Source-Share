#include <cstdlib>

#include "OPT.h"
#include "LRU.h"
#include "FIFO.h"

bool verbose = false; //  控制是否输出调试信息
int maxN = 32; // 最大页数
int N = 320000; // 实存容量

int main() {
//    cout << "THE VIRTUAL ADDRESS STREAM AS FOLLOWS:\n";
    string option; // 算法选择

    /**
     * 生成指令序列
     * A short 两字节的地址空间 使用三种方式生成
     * 0 ~ N * 0.25,    short 2字节中 0_______ ________ 均匀分布
     * 0.25 ~ N * 0.75, 指令连续
     * 0.75 ~ N         short 2字节中 1_______ ________ 均匀分布
     */
    vector<short> A; // 存放虚拟地址
    srand(time(nullptr));
    int i = 0; // 控制变量，用于初始化A
    short x;    // 临时变量，用于存放随机数
    while (i <= N * 0.25) {
        x = rand() % 16384; // 16384 = 2^15 即 0_______ ________ 均匀分布
        A.push_back(x);
        i++;
    }
    while (i > N * 0.25 && i < N * 0.75) {
        x = A[i - 1] + 1;
        A.push_back(x);
        i++;
    }
    while (i < N) {
        x = rand() % 16384 + 16384; //  即 1_______ ________ 均匀分布
        A.push_back(x);
        i++;
    }

    if (verbose) {
        for (int j = 0; j < N; j++) {
            printf("a[%d] =", j);
            printf(" %-10d\t", A[j]);
            if ((j + 1) % 4 == 0)
                cout << endl;
        }
    }

    cout << "输入页面置换算法(123)" << endl;
    cout << "1.opt" << endl;
    cout << "2.lru" << endl;
    cout << "3.fifo" << endl;
    cin >> option;
    if (option == "1") {
        OPT test = OPT(A, maxN, verbose);
        cout << "PAGE NUMBER WITH SIZE 1k FOR EACH ADDRESS IS:\n";
        test.run();
    } else if (option == "2") {
        LRU test = LRU(A, maxN, verbose);
        cout << "PAGE NUMBER WITH SIZE 1k FOR EACH ADDRESS IS:\n";
        test.run();
    } else if (option == "3") {
        FIFO test = FIFO(A, maxN, verbose);
        cout << "PAGE NUMBER WITH SIZE 1k FOR EACH ADDRESS IS:\n";
        test.run();
    }
    return 0;
}

#include "LRU.h"

using namespace std;

LRU::LRU(const vector<short> &A, int maxN, bool verbose) : maxN(maxN), verbose(verbose) {
    a = vector<short>(A);
    pageno.resize(A.size());
}

void LRU::run() {
    getPageNo();
    ofstream out("lru.txt");
    for (int pageAssigned = 4; pageAssigned <= maxN; pageAssigned += 2) {
        printf("PAGE NUMBER WITH SIZE %dk EACH ADDRESS IS:\n", pagesize / 1024);
        vector<int> memory;
        vector<int> clocks_stack; // 用栈的方式实现LRU
        int miss = 0;
        for (int i = 0; i < pageno.size(); i++) {
            auto index = find(memory.begin(), memory.end(), pageno[i]);
            // 求index的过程就是在物理内存中寻找对应页是否存在的过程
            if (index != memory.end()) // 没有缺页
            {
                auto pos = find(clocks_stack.begin(), clocks_stack.end(), pageno[i]); // 在栈中的位置pos
                clocks_stack.erase(pos); // 删除在栈里的index
                clocks_stack.push_back(pageno[i]); // pageno[i]放到栈顶
                if (verbose) {
                    cout << "命中 ";
                }
            } else {
                if (verbose)
                    cout << "缺页 ";
                if (memory.size() < pageAssigned) // 有空闲页 可以直接装入
                {
                    memory.push_back(pageno[i]); // 把此页装到最后空闲位置
                    clocks_stack.push_back(pageno[i]);
                    if (verbose)
                        cout << "装入 ";
                } else // 置换页面
                {
                    if (verbose)
                        cout << "置换 ";
                    int minclocks_stack = clocks_stack.front(); // 栈底是最近未使用的页面
                    clocks_stack.erase(clocks_stack.begin());
                    auto pos2 = find(memory.begin(), memory.end(), minclocks_stack);
                    pos2 = memory.erase(pos2);
                    memory.insert(pos2, pageno[i]);
                    clocks_stack.push_back(pageno[i]);
                }
                miss++;
            }
            if (verbose) {
                for (int k: memory)
                    printf("%d ", k);
                cout << endl;
            }
        }
        printf("%-10d 命中率： %3f\n", pageAssigned, 1 - miss * 1.0 / pageno.size());
        cout << endl;
        out << miss * 1.0 / pageno.size() << endl;
        pagesize *= 2;
    }
    out.close();
}

/**
 * @brief 获取每一个物理地址对应的页号
 */
void LRU::getPageNo() {
    for (int i = 0; i < a.size(); i++) {
        pageno[i] = a[i] / pagesize + 1;
        if (verbose) {
            printf("pageno[%d]=%-10d", i, pageno[i]);
            if ((i + 1) % 4 == 0)
                cout << endl;
        }
    }
}
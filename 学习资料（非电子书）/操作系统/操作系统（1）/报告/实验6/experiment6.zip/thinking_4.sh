#! /bin/bash
ls -l >filedir.txt
mkdir testdir2
tmp=$(find ./*.c)
cp "$tmp" testdir2
cd testdir2 || exit
for filename in *; do
    [[ -e "$filename" ]] || break
    chmod 311 "$filename"
done
ls -l testdir2 >>filedir.txt
id >>filedir.txt
less filedir.txt

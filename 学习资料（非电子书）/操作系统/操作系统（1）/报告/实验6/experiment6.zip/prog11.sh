#! /bin/bash
echo "$HOME"
echo "$PATH"
ls -l "$1" 

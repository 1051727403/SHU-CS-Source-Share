#! /bin/bash
for filename in $(ls); do
    echo "$filename"
done
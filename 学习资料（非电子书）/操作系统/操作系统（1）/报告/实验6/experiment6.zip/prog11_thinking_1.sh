#! /bin/bash
select item in env top set quit
do
    if [ $item = "quit" ]
    then
        break
    else
        $item
    fi
done
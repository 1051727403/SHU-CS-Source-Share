#! /bin/bash
read -p "Please input the file path: " -r file
if [ -d $file ]; then
    echo "$file is a directory"
else
    echo "$file is not a directory"
fi
if [ -f $file ]; then
    echo "$file is a regular file"
else
    echo "$file is not a regular file"
fi
if [ -r $file ]; then
    echo "$file has read permissione"
else
    echo "$file dose not have read permissione"
fi
if [ -w $file ]; then
    echo "$file has write permissione"
else
    echo "$file dose not have write permissione"
fi
if [ -x $file ]; then
    echo "$file has execute permissione"
else
    echo "$file dose not have execute permissione"
fi

#! /bin/zsh
echo "This text is for the qusetion 2!"

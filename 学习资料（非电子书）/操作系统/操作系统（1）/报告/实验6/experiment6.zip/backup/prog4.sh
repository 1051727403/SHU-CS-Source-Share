#! /bin/bash
echo "number of parameters:" $#
echo "Your file name is " $0
if [ $# == 0 ]
then
    echo "Name is not provided"
else
    for VAR in $*
    do
        echo $VAR
    done
fi

#! /bin/bash
echo "Please input your name"
read name
if [ $name ]
then
    echo "Your name is " $name
else
    echo "Name is not provided"
fi

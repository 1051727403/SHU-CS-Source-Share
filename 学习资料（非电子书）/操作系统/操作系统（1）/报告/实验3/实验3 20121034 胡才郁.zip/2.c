#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/wait.h>

int main()
{
    int i;
    if (fork())
    {

        i = wait(0); /*父进程执行的程序段*/
        /* 等待子进程结束*/
        printf("It is parent process.\n");
        printf("The child process,ID number %d, is finished.\n", i);
    }
    else
    {
        printf("It is child process.\n");
        sleep(3);
        /*子进程执行的程序段*/
        exit(0); /*向父进程发出结束信号*/
    }
    return 0;
}

/* Clone the calling process, creating an exact copy.
       Return -1 for errors, 0 to the new process,
       and the process ID of the new process to the old process.  */
#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <sys/wait.h>
int main()
{
    int i, j;
    printf("My pid is %d, my father's pid is %d\n", getpid(), getppid());
    for (i = 0; i < 3; i++)
        if (fork())
        {
            j = wait(0); //等待子进程结束
            printf("%d: The child %d is finished.\n", getpid(), j);
            break;
        } //结束父进程，避免产生新的子进程
        else
        { //进入子进程
            printf("%d pid = % d ppid = % d\n", i, getpid(), getppid());
        }
    return 0;
}
// 例程5：管道通信的实验
/*程序建⽴⼀个管道fd*/
/*⽗进程创建两个⼦进程P1、P2 */
/*⼦进程P1、P2 分别向管道写⼊信息*/
/*⽗进程等待⼦进程结束，并读出管道中的信息*/
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/wait.h>
int main()
{
    int i,
        r, j, k, l, p1, p2, fd[2];
    char buf[50], s[50];
    pipe(fd);                   /*建⽴⼀个管道fd*/
    while ((p1 = fork()) == -1); /*创建⼦进程1*/
        
    if (p1 == 0) /*⼦进程1 执⾏*/
    {
        sprintf(buf, "Child process P1 is sending messages! \n");
        printf("Child process P1! \n");
        write(fd[1], buf, 50); /*信息写⼊管道*/
        sleep(3);
        j = getpid();
        k = getppid();
        printf("P1 %d is weakup. My parent process ID is %d.\n", j, k);
        exit(0);
    }
    else
    {
        while ((p2 = fork()) == -1) /*创建⼦进程2*/
            ;
        if (p2 == 0) /*⼦进程2 执⾏*/
        {
            sprintf(buf, "Child process P2 is sending messages! \n");
            printf("Child process P2! \n");
            write(fd[1], buf, 50); /*信息写⼊管道*/
            sleep(3);
            j = getpid();
            k = getppid();
            printf("P2 %d is weakup. My parent process ID is %d.\n", j, k);
            exit(0);
        }
        else
        {
            l = getpid();
            if ((r = read(fd[0], s, 50) == -1))
                printf("Can't read pipe. \n");
            else
                printf("Parent %d: %s \n", l, s);
            if ((r = read(fd[0], s, 50) == -1))
                printf("Can't read pipe. \n");
            else
                printf("Parent %d: %s \n", l, s);
            exit(0);
        }
    }
    return 0;
}
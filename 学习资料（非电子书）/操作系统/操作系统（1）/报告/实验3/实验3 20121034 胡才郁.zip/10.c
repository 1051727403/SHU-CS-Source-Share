#include <stdio.h>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>

#define P sem_wait
#define V sem_post
#define full &full_
#define mutex &mutex_
#define empty &empty_


const int PRODUCER_NUM = 10;
const int CONSUMER_NUM = 10;
const int CACHE_SIZE = 10;
const double SLEEP_TIME = 1;

sem_t mutex_;
sem_t full_;
sem_t empty_;

static int cache_ = 0;

void *producer(void *arg)
{
    int id = *((int*)arg);
    while (1)
    {
        sleep(SLEEP_TIME);
        P(empty);
        P(mutex);
        int empty_num;
        sem_getvalue(empty, &empty_num);
        cache_++;
        // printf("%d号生产者生产商品 此时缓冲区中有%d个商品\n", id, CACHE_SIZE - empty_num);
        printf("%d号生产者生产商品 此时缓冲区中有%d个商品\n", id, cache_);
        V(mutex);
        V(full);
    }
}
void *consumer(void *arg)
{
    int id = *((int*)arg);
    while (1)
    {
        sleep(SLEEP_TIME);
        P(full);
        P(mutex);
        int full_num;
        sem_getvalue(full, &full_num);
        cache_--;
        printf("%d号消费者购买商品 此时缓冲区中有%d个商品\n", id, cache_);
        V(mutex);
        V(empty);
    }
}

int main()
{
    sem_init(mutex, 0, 1);
    sem_init(full, 0, 0);
    sem_init(empty, 0, CACHE_SIZE);
    
    pthread_t producers[PRODUCER_NUM];
    pthread_t consumers[CONSUMER_NUM];

    for (int i = 0; i < PRODUCER_NUM; i++)
    {
        pthread_create(&producers[i], NULL, producer, &i);
    }
    
    for (int i = 0; i < PRODUCER_NUM; i++)
    {
        pthread_create(&consumers[i], NULL, consumer, &i);
    }
    

    pthread_exit(0);

    return 0;
}

/*建立进程树*/
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/wait.h>

int main()
{
    int i;
    printf("My pid is % d, my father's pid is % d\n", getpid(), getppid());
    for (i = 0; i < 3; i++)
        if (fork() == 0)
            printf("%d pid = % d ppid = % d\n", i, getpid(), getppid());
        else
        {
            int j = wait(0);
            printf("%d: The child % d is finished.\n", getpid(), j);
        }
}
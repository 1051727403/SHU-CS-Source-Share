/* 例程7：软中断信号实验 ⽗进程向⼦进程发送18号软中断信号后等待。⼦进程收到信号，执⾏指定的程序，再将⽗进程唤醒。*/
#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/wait.h>
int main()
{
    int i, j, k;
    void func();
    signal(18, &func);   /*设置18号信号的处理程序*/
    if ((i = fork()))    /*创建⼦进程*/
    {                    /*⽗进程执⾏*/
        j = kill(i, 18); /*向⼦进程发送信号,i是⼦进程进程号，将此信号发送给进程ID为pid的进程； 
        第⼆个参数表示要发送的信号的编号，假如其值为0则没有任何信号送出，但是系统会执⾏错误检查，通常会利⽤sig值为0来检验某个进程是否仍在成功执⾏时，返回0；
        失败返回-1。*/
        printf("Parent: signal 18 has been sent to child %d,returned %d.\n", i, j);
        k = wait(0); /*⽗进程被唤醒*/
        printf("After wait %d, Parent %d: finished.\n", k, getpid());
    }
    else
    { /*⼦进程执⾏*/
        sleep(5);
        printf("Child %d: A signal from my parent is recived.\n", getpid());
    } /*⼦进程结束，向⽗进程发⼦进程结束信号*/

    return 0;
}
void func() /*处理程序*/
{
    int m;
    m = getpid();
    printf("I am Process %d: It is signal 18 processing function.\n", m);
}
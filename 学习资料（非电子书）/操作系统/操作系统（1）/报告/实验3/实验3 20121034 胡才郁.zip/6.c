// 例程5：管道通信的实验
/*程序建⽴⼀个管道fd*/
/*⽗进程创建两个⼦进程P1、P2 */
/*⼦进程P1、P2 分别向管道写⼊信息*/
/*⽗进程等待⼦进程结束，并读出管道中的信息*/
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <unistd.h>
#include <sys/wait.h>
int main()
{
    int i, r, j, k, l, p1, p2, fd[2];
    char buf[50], s[50];
    pipe(fd);                   /*建⽴⼀个管道fd*/
    while ((p1 = fork()) == -1); /*创建⼦进程1*/
        
    if (p1 == 0) /*⼦进程1 执⾏*/
    {
        // sleep(4);
        // lockf(fd[1], 1, 0); /*管道写⼊端加锁*/
        sprintf(buf, "Child process P1 is sending messages! \n");
        printf("Child process P1! \n");
        write(fd[1], buf, 50); /*信息写⼊管道*/
        // lockf(fd[1], 0, 0); /*管道写⼊端解锁*/
        // sleep(1);
        j = getpid();
        k = getppid();
        printf("P1 %d is wakeup. My parent process ID is %d.\n", j, k);
        sleep(1);
        exit(0);
    }
    else
    {
        while ((p2 = fork()) == -1); /*创建⼦进程2*/
            
        if (p2 == 0) /*⼦进程2 执⾏*/
        {
            sleep(2);
            lockf(fd[1], 1, 0); /*管道写⼊端加锁*/
            sprintf(buf, "Child process P2 is sending messages! \n");
            // sleep(2);
            printf("Child process P2! \n");
            write(fd[1], buf, 50); /*信息写⼊管道*/
            // lockf(fd[1], 0, 0); /*管道写⼊端解锁*/
            j = getpid();
            k = getppid();
            printf("P2 %d is wakeup. My parent process ID is %d.\n", j, k);
            sleep(1);
            exit(0);
        }
        else
        {
            l = getpid();
            wait(0); /* 等待被唤醒*/
            if ((r = read(fd[0], s, 50) == -1))
                printf("Can't read pipe. \n");
            else
                printf("Parent %d: %s \n", l, s);
            wait(0); /* 等待被唤醒*/
            if ((r = read(fd[0], s, 50) == -1))
                printf("Can't read pipe. \n");
            else
                printf("Parent %d: %s \n", l, s);
            exit(0);
        }
    }
    return 0;
}
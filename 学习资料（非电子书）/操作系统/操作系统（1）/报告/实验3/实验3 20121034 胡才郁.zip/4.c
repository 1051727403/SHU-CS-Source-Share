/*创建子进程，子进程启动其它程序*/
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#include <sys/wait.h>

int main()
{
    int child_pid1, child_pid2, child_pid3;
    int pid, status;
    setbuf(stdout, NULL);
    child_pid1 = fork(); /*创建子进程1*/
    if (child_pid1 == 0)
    {
        execlp("echo", "echo", "child process 1", (char *)0); /*子进程1 启动其它程序*/
        // Print a message describing the meaning of the value of errno.
        perror("exec1 error.\n ");
        exit(1);
    }
    child_pid2 = fork(); /*创建子进程2*/
    if (child_pid2 == 0)
    {
        execlp("date", "date", (char *)0); /*子进程2 启动其它程序*/
        perror("exec2 error.\n ");
        exit(2);
    }
    child_pid3 = fork(); /*创建子进程3*/
    if (child_pid3 == 0)
    {
        execlp("ls", "ls", (char *)0); /*子进程3 启动其它程序*/
        perror("exec3 error.\n ");
        exit(3);
    }
    puts("Parent process is waiting for child process return!");
    
    // Wait for a child to die.  When one does, put its status in *STAT_LOC
    // and return its process ID.  For errors, return (pid_t) -1.
    while ((pid = wait(&status)) != -1) /*等待子进程结束*/
    {
        if (child_pid1 == pid) /*若子进程1 结束*/
            printf("child process 1 terminated with status %d\n", (status >> 8));
        else
        {
            if (child_pid2 == pid) /*若子进程2 结束*/
                printf("child process 2 terminated with status %d\n", (status >> 8));
            else
            {
                if (child_pid3 == pid) /*若子进程3 结束*/
                    printf("child process 3 terminated with status %d\n", (status >> 8));
            }
        }
    }
    puts("All child processes terminated.");
    puts("Parent process terminated.");
    exit(0);
}
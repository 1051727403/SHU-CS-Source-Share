/*创建子进程的实验。子进程继承父进程的资源，修改了公共变量globa 和私有变
量vari。观察变化情况。*/
#include <stdio.h>
#include <sys/types.h>
#include <unistd.h>
#include <stdlib.h>

int globa = 4;
int main()
{
    pid_t pid;
    int vari = 5;
    printf("before fork.\n");
    if ((pid = fork()) < 0)
    {

        printf("fork error.\n"); /*创建失败处理*/
        exit(0);
    }

    else if (pid == 0)
    { /*子进程执行*/
        globa++;
        vari--;
        printf("Child %d changed the vari and globa.\n", getpid());
    }
    else{ /*父进程执行*/
        sleep(1);
        printf("Parent %d did not changed the vari and globa.\n", getpid());
    }
    printf("pid=%d, globa=%d, vari=%d\n", getpid(), globa, vari); /*都执行*/
    exit(0);
    
}
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>

int main()
{
    printf("------------父进程信息------------\n");
    printf("进程标识 %d\n", getpid());
    printf("组表示 %d\n", getgid());
    printf("用户标识 %d\n", getuid());
    printf("------------父进程信息------------\n");
    printf("\n");

    int i = fork();

    if (i == 0)
    {
        printf("------------子进程------------\n");
        printf("在⼦进程中执⾏了pwd程序\n");
        execlp("pwd", "pwd", NULL);
        printf("⼦进程结束\n");
        printf("------------子进程------------\n");
    }
    else
    {
        printf("------------父进程------------\n");
        sleep(5);
        printf("是否结束父进程? Y/N \n");
        char c;
        while ((c = getchar()))
        {
            if (c == 'Y' || c == 'y')
            {
                printf("父进程结束\n");
                exit(0);
            }
            else if (c == 'N' || c == 'n')
            {
                printf("父进程继续\n");
                printf("是否结束父进程? Y/N \n");
            }
        }
        printf("------------父进程------------\n");
    }

    return 0;
}
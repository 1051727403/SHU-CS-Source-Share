/*客户进程向服务器进程发出信号，服务器进程接收作出应答，并再向客户返回消息。*/
/*服务者程序*/
#include <sys/types.h>
#include <sys/ipc.h>
#include <sys/msg.h>
#include <stdio.h>
#include <unistd.h>
#include <stdlib.h>
#define MSGKEY 75
struct msgform /*定义消息结构*/
{
    long mtype;
    char mtext[256];
} msg;
int msgqid;
int main()
{
    int i, pid, *pint;
    extern cleanup();
    for (i = 0; i < 20; i++) /*定义消息结构*/
        signal(i, cleanup);
    msgqid = msgget(MSGKEY, 0777 | IPC_CREAT); /*建⽴消息队列*/
    for (;;)                                   /*等待接受消息*/
    {
        msgrcv(msgqid, &msg, 256, 1, 0); /* 接受消息*/
        pint = (int *)msg.mtext;
        pid = *pint;
        printf("Server :receive from pid %d\n", pid); /*显示消息来源*/
        msg.mtype = pid;
        *pint = getpid();                     /*加⼊⾃⼰的进程标识*/
        msgsnd(msgqid, &msg, sizeof(int), 0); /*发送消息*/
    }
    return 0;
}
cleanup()
{
    msgctl(msgqid, IPC_RMID, 0);
    exit(0);
}
#include <stdio.h>
#include <pthread.h>
#include <semaphore.h>
#include <unistd.h>

#define P sem_wait
#define V sem_post
#define rw &rw_
#define mutex &mutex_
#define w &w_

const int WIRTER_NUM = 1;
const int READER_NUM = 1;
const int SLEEP_TIME = 1;

int count = 0;
sem_t rw_;
sem_t w_;
sem_t mutex_;

void *writer(void *arg)
{
    int id = *((int *)arg);
    while (1)
    {
        sleep(SLEEP_TIME);
        P(w); //新增
        P(rw);
        printf("%d: 写文件.\n", id);
        V(rw);
        V(w); //新增
    }
}

void *reader(void *arg)
{
    int id = *((int *)arg);
    while (1)
    {
        sleep(SLEEP_TIME);
        P(w); //新增
        P(mutex);
        if (count == 0)
        {
            P(rw);
        }
        count++;
        V(mutex);
        V(w); //新增
        printf("%d: 读文件.\n", id);
        P(mutex);
        count--;
        if (count == 0)
        {
            V(rw);
        }
        V(mutex);
    }
}

int main()
{
    sem_init(rw, 0, 1);
    sem_init(mutex, 0, 1);
    sem_init(w, 0, 1);

    pthread_t writers[WIRTER_NUM];
    pthread_t readers[READER_NUM];

    for (int i = 0; i < WIRTER_NUM; i++)
    {
        pthread_create(&writers[i], NULL, writer, &i);
    }

    for (int i = 0; i < READER_NUM; i++)
    {
        pthread_create(&readers[i], NULL, reader, &i);
    }

    pthread_exit(0);

    return 0;
}
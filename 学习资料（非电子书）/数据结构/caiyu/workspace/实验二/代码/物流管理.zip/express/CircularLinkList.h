//
// Created by Silence on 2021/12/8.
//

#ifndef DS_CIRCULARLINKLIST_H
#define DS_CIRCULARLINKLIST_H

#include <iostream>
#include "Node.h"

using namespace std;

enum Status {
    SUCCESS, FAIL, UNDER_FLOW, OVER_FLOW, RANGE_ERROR, DUPLICATE_ERROR,
    NOT_PRESENT, ENTRY_INSERTED, ENTRY_FOUND, VISITED, UNVISITED
};
template<typename T>
class CircularLinkList {
protected:
    int length;
    Node<T> *head;
public:
    // ����Ϊ�Ĵ���
    // 1.���캯��
    CircularLinkList();
    CircularLinkList(T v[], int size);
    // 2.��������(�ڲ�����Clear())
    virtual ~CircularLinkList();
    void Clear(); // ���ѭ��������
    void Show() const;
    int LocateElem(const T &e) const; // ��ֵ���ң����ص�һ�����ҵ���Ԫ�أ����δ���ҵ����򷵻�0
    Status GetElem(int i, T &e) const; // ��λ����
    Status SetElem(int i, const T &e); // �޸�ָ��λ��Ԫ��ֵ
    Status DeleteElem(int i, T &e); // ɾ��ָ��Ԫ��
    Status InsertElem(int i, const T &e); // ����ָ��Ԫ��
};
template<typename T>
CircularLinkList<T>::CircularLinkList() : head(NULL),length(0) {}
template<typename T>
CircularLinkList<T>::CircularLinkList(T *v, int size) : head(NULL), length(size) {
    Node<T> *p = head = new Node<T>(v[0], head);
    for (int i = 1; i < size; i++) {
        p->next = new Node<T>(v[i], head);
        p = p->next; // ѭ������ʱpָ��head
    }
}
template<typename T>
void CircularLinkList<T>::Show() const {
    if (head == NULL)
        return;
    Node<T> *p = head;
    while (p->next != head) {
        cout << p->data << " ";
        p = p->next;
    }
    cout << p->data << endl;
}
template<typename T>
CircularLinkList<T>::~CircularLinkList() {
    Clear();
}
template<typename T>
void CircularLinkList<T>::Clear() {
    if (head == NULL)
        return;
    T t;
    while (length > 0) {
        DeleteElem(1, t);
    }
    head = NULL;
}
template<typename T>
int CircularLinkList<T>::LocateElem(const T &e) const {
    if (head == NULL)
        return 0;
    if (head->data == e)
        return 1;
    Node<T> *p = head->next;
    int count = 2;
    while (p != head && p->data != e) {
        count++;
        p = p->next;
    }
    return (p != head) ? count : 0;
}
template<typename T>
Status CircularLinkList<T>::GetElem(int i, T &e) const {
    if (i < 1 || i > length)
        return RANGE_ERROR;
    Node<T> *p = head;
    int count = 1;
    for (; count < i; count++) {
        p = p->next;
    }
    e = p->data;
    return ENTRY_FOUND;
}
template<typename T>
Status CircularLinkList<T>::SetElem(int i, const T &e) {
    if (i < 1 || i > length)
        return RANGE_ERROR;
    Node<T> *p = head;
    int count = 1;
    for (; count < i; count++) {
        p = p->next;
    }
    p->data = e;
    return ENTRY_FOUND;
}
template<typename T>
Status CircularLinkList<T>::DeleteElem(int i, T &e) {
    if (i < 1 || i > length)
        return RANGE_ERROR;
    if(length == 1){
    	delete head;
    	head = NULL;
    	length = 0;
    	return SUCCESS;
	} 
    Node<T> *p, *q;
    if (i == 1) {
        p = head;
        int count = 1;
        for (; count < length; count++) {
            p = p->next;
        } // Ѱ��ĩβ�ڵ��λ��
        q = head;
        head = head->next;
        p->next = head;
    } else {
        p = head;
        for (int count = 2; count < i; count++) {
            p = p->next;
        }
        q = p->next;
        p->next = q->next;
    }
    e = q->data;
    length--;
//    cout << "______length______:" << length << endl;
    delete q;
    return SUCCESS;
}
template<typename T>
Status CircularLinkList<T>::InsertElem(int i, const T &e) {
    Node<T> *p, *q;
	if(length == 0){
		p = new Node<T>(e,NULL);
		head = p;
		head->next = head;
		length = 1;
		return SUCCESS;
	}
    if (i < 1 || i > length)
        return RANGE_ERROR;
    if (i == 1) {
        p = head;
        int count = 1;
        for (; count < length; count++) {
            p = p->next;
        } // Ѱ��ĩβ�ڵ��λ��
        q = new Node<T>(e, head);
        head = q;
        p->next = head;
    } else {
        p = head;
        for (int count = 2; count < i; count++) {
            p = p->next;
        }
        q = new Node<T>(e, p->next);
        p->next = q;
    }
    length++;
//    cout << "______length______:" << length << endl;
    return SUCCESS;
}
#endif //DS_CIRCULARLINKLIST_H

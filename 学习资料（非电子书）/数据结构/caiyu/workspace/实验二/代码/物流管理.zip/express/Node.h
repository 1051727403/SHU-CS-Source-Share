//
// Created by Silence on 2021/12/8.
//

#ifndef DS_NODE_H
#define DS_NODE_H

#include <iostream>
#include "CircularLinkList.h"

using namespace std;
template<typename T>
class CircularLinkList; // 提前声明

template<typename T>
class Node {
    friend CircularLinkList<T>;
protected:
    T data; // 数据域
    Node<T> *next; // 指针域
public:
    Node(); // 无参构造函数
    Node(T e, Node<T> *link = NULL); // 构造函数
};
template<typename T>
Node<T>::Node() {
    next = NULL;
}
template<typename T>
Node<T>::Node(T e, Node<T> *link) {
    data = e;
    next = link;
}
#endif //DS_NODE_H


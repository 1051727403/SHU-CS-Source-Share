#ifndef Gift_H
#define Gift_H

#include <bits/stdc++.h>
#include "CircularLinkList.h"

using namespace std;

void WarnFilled(ostream &out){
	out << "����Warning����ǰ������Ʒ����ѳ���1000��ϵͳ�Զ���������Ϊ1000�����ಿ�ֽ����ᱻ���롣";
}

class Gift{
public:
	Gift(string name="noname",string code="0000",int num=0) : Name(name),Code(code),Num(num)
	{
		if(Num>1000)
		{
			Num=1000;
			WarnFilled(cout);
		}
	}
	friend class CircularLinkList<Gift>;
	string Askname() const;
	string Askcode() const;
	int Asknum() const;
	void Setdata(string name,string code,int num);
	void Addnum(int x);
	bool Delnum(int x);
	void ShowData(ostream &out) const;
	operator =(const Gift & b){
		Name=b.Name;Code=b.Code;Num=b.Num;
	}
	friend ostream & operator <<(ostream &out,const Gift &a);
	bool operator ==(const Gift & b) const{
		return Name==b.Name && Code==b.Code;
	}
	bool operator !=(const Gift & b) const{
		return !(*this==b);
	}
private:
	string Name, Code;
	int Num;
};

string Gift::Askname() const
{
	return Name;
}
string Gift::Askcode() const
{
	return Code;
}
int Gift::Asknum() const
{
	return Num;
}
void Gift::Setdata(string name,string code,int num)
{
	Name=name;
	Code=code;
	Num=num;
	if(Num>1000){
		Num=1000;
		WarnFilled(cout);
	}
}
void Gift::Addnum(int x)
{
	if(x<0)Delnum(-x);
	Num+=x;
	if(Num>1000){
		Num=1000;
		WarnFilled(cout);
	}
}
bool Gift::Delnum(int x){
	if(x<0){
		Addnum(-x);
		return 0;
	}
	Num-=x;
	if(Num<=0){
		Num=0;
		return 1;
	}
	return 0;
}
void Gift::ShowData(ostream &out) const
{
	out << "��ţ�"<< Code << "\t���ƣ�" << Name << "\t������" << Num << endl; 
}
ostream & operator<<(ostream &out, const Gift &a)
{
	a.ShowData(out);
	return out;
}



#endif

#ifndef ILLEGAL_INDEX_H
#define ILLEGAL_INDEX_H

#include<exception>
#include<cstring>
#include <string>

class illegalIndex : public std::exception
{
private:
	std::string errorInfo;
public:
	illegalIndex(int index)
	{
		errorInfo = index;
	}

	std::string printInfo() { return errorInfo; }
};
#endif


//题目一：使用 Eclipse IDE 或 IntelliJ IDEA，创建第一个 Java 项目（HelloJava）和 Java
//程序；在 IDE 环境下编辑、编译和解释运行第一个 Java 程序；
public class Question_1 {
    public static void main(String[] args) {
        System.out.println("Hello world!");
    }
}